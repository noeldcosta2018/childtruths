# Design System Specification: The Nurtured Path

This design system is a high-end, editorial-inspired framework crafted for an empathetic parenting experience. It rejects the "industrial" feel of standard UI kits in favor of a "Digital Sanctuary"—a space that feels as warm as a nursery and as dependable as a clinical expert. 

By prioritizing tonal depth over rigid borders and organic fluidity over strict grids, we create an environment that calms the user while guiding them with authority.

---

## 1. Creative North Star: "The Modern Caretaker"
The design system is built on the philosophy of **The Modern Caretaker**. It avoids the chaotic "primary color" aesthetic often associated with childcare. Instead, it uses sophisticated, muted earth tones and expansive white space to signal expertise. 

**Signature Aesthetic:**
- **Intentional Asymmetry:** Break the grid. Allow hero images or organic "blob" shapes to bleed off the edges of the viewport to create a sense of life and movement.
- **Overlapping Elements:** Place typography over the edge of containers to create a tactile, layered feel—like a scrapbooked journal.
- **Editorial Scale:** Use extreme contrast between massive `display-lg` headers and intimate `body-md` text to establish a clear, authoritative narrative.

---

## 2. Color & Surface Philosophy

The palette moves away from "app-like" vibrancy toward "lifestyle-editorial" warmth.

### The "No-Line" Rule
**Strict Mandate:** 1px solid borders are prohibited for sectioning. 
Structure is defined through **Background Shifts**. To separate a content block, transition from `surface` (#fef8f1) to `surface-container-low` (#f9f3ec). This creates a "soft-edge" layout that feels premium and less technical.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of fine cotton paper.
- **Base Layer:** `surface` (#fef8f1)
- **Secondary Content:** `surface-container-low` (#f9f3ec)
- **Interactive Cards:** `surface-container-lowest` (#ffffff) to make them pop against the cream background.
- **High Importance/Callouts:** `secondary-container` (#d1e6c7) for a "Sage" breath of fresh air.

### The "Glass & Gradient" Rule
To add soul to the UI, use subtle radial gradients.
- **Primary CTAs:** Instead of a flat `primary` (#914b31), use a linear gradient from `primary` to `primary_container` (#d98466) at a 45-degree angle.
- **Floating Navigation:** Use `surface_bright` with a 70% opacity and a `20px` backdrop-blur to create a "frosted glass" effect, allowing the warm terracottas to bleed through as the user scrolls.

---

## 3. Typography: The Conversational Expert

We pair the friendly approachability of **Plus Jakarta Sans** with the functional clarity of **Manrope**.

| Role | Token | Font | Size | Intent |
| :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | Plus Jakarta Sans | 3.5rem | Bold, warm, and inviting. Use for welcome screens. |
| **Headline** | `headline-md` | Plus Jakarta Sans | 1.75rem | Friendly advice and section headers. |
| **Body** | `body-lg` | Manrope | 1.0rem | The "Expert Voice." Highly legible and trustworthy. |
| **Label** | `label-md` | Manrope | 0.75rem | Metadata and small annotations. |

*Note: Always use `on_tertiary_container` (#00383f) or `on_background` (#1d1b17) for text to ensure high-contrast accessibility against the cream and sage backgrounds.*

---

## 4. Elevation, Depth & Ghost Borders

We avoid the "floating card" look of the 2010s. Depth is achieved through **Tonal Layering**.

- **The Layering Principle:** To highlight a card, don't use a shadow first; use a color shift. Place a `surface-container-lowest` card on a `surface-container` background.
- **Ambient Shadows:** If a shadow is required for a floating Action Button (FAB), use the `on_surface` color at 6% opacity with a `32px` blur and `8px` Y-offset. This mimics soft, overhead nursery lighting.
- **The "Ghost Border" Fallback:** If a boundary is required (e.g., in a complex form), use the `outline_variant` (#d9c1ba) at **20% opacity**. It should be felt, not seen.

---

## 5. Component Signature Styles

### Buttons: The Tactile Pill
- **Primary:** `primary` (#914b31) background with `on_primary` (#ffffff) text. Use `xl` (3rem) corner radius.
- **Secondary:** `secondary_container` (#d1e6c7) with `on_secondary_container` (#55684f). This "Sage" button feels supportive and non-threatening.
- **States:** On hover/press, add a subtle `2px` inner glow rather than a dark overlay to maintain the "glow" of the brand.

### Cards: The "Organic Container"
- **Radius:** Never use less than `xl` (3rem/48px) for main content cards. 
- **Separation:** Forbid divider lines. Use `spacing-8` (2.75rem) of vertical white space to separate topics. 
- **Nesting:** Place a `primary_fixed` (#ffdbcf) small badge inside a `surface_container_lowest` card for a sophisticated "Terracotta" accent.

### Inputs & Fields
- **Background:** Always `surface_container_highest` (#e7e2db) to provide a clear "trough" for typing.
- **Focus:** Transition the background to `surface_container_lowest` (#ffffff) and add a `2px` ghost border of `primary` at 40% opacity.

### Navigation: The Floating Dock
The bottom navigation should not be a full-width bar. It should be a floating "pod" with a `full` (9999px) radius, utilizing the **Glassmorphism** rule for a lightweight, airy feel.

---

## 6. Do’s and Don'ts

### Do
- **Do** use "Organic Blobs" (SVGs) in `secondary_fixed` (#d4e9ca) as background decorations behind text.
- **Do** lean into `tertiary` (#1d6772) for interactive elements like toggles and links; it provides a "supportive teal" that anchors the warmer colors.
- **Do** use the `24` (8.5rem) spacing token for hero section bottom margins to allow the layout to "breathe."

### Don't
- **Don't** use pure black (#000000) for anything. It breaks the "Warm/Nurturing" spell. Use `on_background` (#1d1b17).
- **Don't** use sharp 90-degree corners. Even for small tags, the minimum radius is `sm` (0.5rem).
- **Don't** use standard "Error Red" for non-critical warnings. Use a soft tint of `error_container` (#ffdad6) to keep the parent from panicking.